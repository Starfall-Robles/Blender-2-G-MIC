sizeopts = (
    ('Shrink', 'Shrink', ''),
    ('Expand', 'Expand', ''),
    ('Repeat (Memory consuming)', 'Repeat (Memory consuming)', ''),
)
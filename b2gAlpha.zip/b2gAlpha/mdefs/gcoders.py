theauthors= (
    ('Filter Author: David Tschumperle'),
    ('Filter Authors: Lyle Kroll & David Tschumperle'),
    ('Filter Authors: Rod-GimpChat-David Tschumperle'),
    ('Filter Author: Photocomix'),
)   

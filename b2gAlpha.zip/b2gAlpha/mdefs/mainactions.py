mainactinfo = (
    ('Erosion', 'EROSION', ''),
    ('Dilation', 'DILATION', ''),
    ('Opening', 'OPENING', ''),
    ('Closing', 'CLOSING', ''),
)   
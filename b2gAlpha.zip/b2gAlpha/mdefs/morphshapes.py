mshapes = (
    ('Square', 'SQUARE', ''),
    ('Octagonal', 'OCTAGONAL', ''),
    ('Circular', 'CIRCULAR', ''),
)   
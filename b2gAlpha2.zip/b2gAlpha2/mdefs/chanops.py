mchanopts = (
    ('None', 'NONE', ''),
    ('Cut', 'CUT', ''),
    ('Stretch', 'STRETCH', ''),
)
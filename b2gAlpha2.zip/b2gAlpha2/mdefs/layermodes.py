modetypes = (
    ('RGBA foreground + background (2 layers)', 'RGBA foreground + background (2 layers)', ''),
    ('RGB image + binary mask (2 layers)', 'RGB image + binary mask (2 layers)', ''),
    ('RGBA image (updatable / 1 layer)', 'RGBA image (updatable / 1 layer)', ''),
    ('RGBA image (full-transparency / 1 layer)', 'RGBA image (full-transparency / 1 layer)', ''),
)
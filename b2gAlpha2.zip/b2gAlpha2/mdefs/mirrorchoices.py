mirrors = (
    ('None', 'None', ''),
    ('X-axis', 'X-axis', ''),
    ('Y-axis', 'Y-axis', ''),
    ('XY-axes', 'XY-axes', ''),
)
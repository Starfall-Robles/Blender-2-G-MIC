﻿restypesz = (
  ('Very High (even slower)', 'Very High (even slower)', ''),
  ('High (slower)', 'High (slower)', ''),
  ('Medium', 'Medium', ''),
  ('Small (faster)', 'Small (faster)', ''),
)
